from django.contrib import admin
from .models import Liga, Equipo, Jugador

# Register your models here.

admin.site.register(Liga)
admin.site.register(Equipo)
admin.site.register(Jugador)