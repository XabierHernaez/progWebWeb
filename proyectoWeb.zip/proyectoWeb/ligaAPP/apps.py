from django.apps import AppConfig


class LigaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ligaAPP'
